
public interface IPooledObject
{
  public void ObjectSPawn();
}
