
public interface IPooledObject
{
  public void ObjectSPawn(bool inTutorial);
}
